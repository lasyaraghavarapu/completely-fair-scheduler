/*
 ============================================================================
 Name        : hev-task-executer.h
 Author      : Heiher <r@hev.cc>
 Copyright   : Copyright (c) 2017 everyone.
 Description :
 ============================================================================
 */

#ifndef __HEV_TASK_EXECUTER_H__
#define __HEV_TASK_EXECUTER_H__

#include "hev-task-private.h"

extern void hev_task_executer (HevTask *task);

#endif /* __HEV_TASK_EXECUTER_H__ */
